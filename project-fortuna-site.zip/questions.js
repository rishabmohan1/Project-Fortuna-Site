/* =========================================================
   Project Fortuna, form definition
   Mirrors the Google Form exactly. Everything the form asks
   lives here; script.js only renders and submits it.

   Option `value` strings must match Google's option text
   character for character, or that answer arrives blank.
   Re-check them against FB_PUBLIC_LOAD_DATA_ after any edit
   to the Google Form.
   ========================================================= */

/* The language question sits alone in section 0 and routes to
   one of three survey sections. */
var LANG_FIELD = "entry.1089865305";

var UI = {
  en: {
    code: "en",
    langValue: "English",
    section: 1,
    nav: {
      continue: "Continue",
      back: "Back",
      submit: "Submit application",
      submitting: "Submitting…"
    },
    stepOf: "Step {n} of {total}",
    requiredAbbr: "required",
    optional: "(optional)",
    errorSummaryTitle: "Please fix the following before continuing",
    errors: {
      select: "Please select an option.",
      required: "This field is required.",
      email: "Please enter a valid email address.",
      phone: "Please enter a valid phone number.",
      other: "Please fill in the details."
    },
    otherLabel: "Other",
    otherPlaceholder: "Please specify",
    footnote: "Your responses are sent to Innodata for screening purposes only.",
    success: {
      title: "Thank you for your submission",
      body: "We’ll review your responses and get back to you within 2 business days. If you have any questions, please reach out to"
    },
    submitError: {
      title: "We couldn’t submit your application.",
      body: "Please check your connection and try again, or email"
    },
    intro: {
      eyebrow: "Now accepting participants",
      title: "Turn everyday tasks into AI training data",
      body: "Record yourself performing household chores, such as doing laundry, tidying up, or organizing items, using a head-mounted smartphone. Enjoy flexible hours and work from home, no experience required. Be part of building the future of robotics.",
      points: [
        "Paid per approved recording",
        "Work from home on your own schedule",
        "Head strap provided or reimbursed"
      ],
      note: "Fill out the form to check your eligibility."
    },
    languageStep: {
      title: "Language",
      question: "What language would you want to complete the survey in?"
    }
  },

  es: {
    code: "es",
    langValue: "Español",
    section: 2,
    nav: {
      continue: "Continuar",
      back: "Atrás",
      submit: "Enviar solicitud",
      submitting: "Enviando…"
    },
    stepOf: "Paso {n} de {total}",
    requiredAbbr: "obligatorio",
    optional: "(opcional)",
    errorSummaryTitle: "Corrige lo siguiente antes de continuar",
    errors: {
      select: "Selecciona una opción.",
      required: "Este campo es obligatorio.",
      email: "Introduce un correo electrónico válido.",
      phone: "Introduce un número de teléfono válido.",
      other: "Completa los detalles."
    },
    otherLabel: "Otro",
    otherPlaceholder: "Especifica",
    footnote: "Tus respuestas se envían a Innodata únicamente con fines de selección.",
    success: {
      title: "Gracias por tu envío",
      body: "Revisaremos tus respuestas y nos pondremos en contacto contigo en un plazo de 2 días hábiles. Si tienes alguna pregunta, comunícate con"
    },
    submitError: {
      title: "No pudimos enviar tu solicitud.",
      body: "Revisa tu conexión e inténtalo de nuevo, o escribe a"
    },
    intro: {
      eyebrow: "Buscando participantes",
      title: "Convierte las tareas cotidianas en datos de entrenamiento para IA",
      body: "Grábate realizando labores domésticas, como lavar la ropa, ordenar o clasificar objetos, utilizando un teléfono inteligente sujeto a la cabeza. Disfruta de un horario flexible y trabaja desde casa, no se requiere experiencia. Forma parte de la construcción del futuro de la robótica.",
      points: [
        "Pago por cada grabación aprobada",
        "Trabaja desde casa con tu propio horario",
        "Correa para la cabeza proporcionada o reembolsada"
      ],
      note: "¡Completa el formulario para verificar si cumples con los requisitos!"
    },
    languageStep: {
      title: "Idioma",
      question: "¿En qué idioma quieres completar la encuesta?"
    }
  },

  pt: {
    code: "pt",
    langValue: "Português",
    section: 3,
    nav: {
      continue: "Continuar",
      back: "Voltar",
      submit: "Enviar inscrição",
      submitting: "Enviando…"
    },
    stepOf: "Etapa {n} de {total}",
    requiredAbbr: "obrigatório",
    optional: "(opcional)",
    errorSummaryTitle: "Corrija o seguinte antes de continuar",
    errors: {
      select: "Selecione uma opção.",
      required: "Este campo é obrigatório.",
      email: "Digite um e-mail válido.",
      phone: "Digite um número de telefone válido.",
      other: "Preencha os detalhes."
    },
    otherLabel: "Outro",
    otherPlaceholder: "Especifique",
    footnote: "Suas respostas são enviadas à Innodata apenas para fins de triagem.",
    success: {
      title: "Obrigado pelo seu envio",
      body: "Analisaremos suas respostas e entraremos em contato em até 2 dias úteis. Caso tenha alguma dúvida, entre em contato pelo e-mail"
    },
    submitError: {
      title: "Não foi possível enviar sua inscrição.",
      body: "Verifique sua conexão e tente novamente, ou envie um e-mail para"
    },
    intro: {
      eyebrow: "Aceitando participantes",
      title: "Transforme tarefas do dia a dia em dados para treinamento de IA",
      body: "Grave-se fazendo tarefas domésticas, como lavar roupa, arrumar a casa ou organizar objetos, usando seu smartphone montado na cabeça. Horários flexíveis, trabalho de casa e sem necessidade de experiência. Faça parte da construção do futuro da robótica.",
      points: [
        "Pagamento por gravação aprovada",
        "Trabalhe de casa no seu próprio horário",
        "Faixa de cabeça fornecida ou reembolsada"
      ],
      note: "Preencha o formulário para verificar se você é elegível!"
    },
    languageStep: {
      title: "Idioma",
      question: "Em qual idioma você gostaria de responder a pesquisa?"
    }
  }
};

/* ---------------------------------------------------------
   Survey definitions, one per language.
   Structurally identical shape; only IDs and copy differ.
   --------------------------------------------------------- */

var SURVEYS = {

  en: [
    {
      title: "Your details",
      fields: [
        { id: "entry.812932508", type: "text", label: "First name", required: true, autocomplete: "given-name" },
        { id: "entry.392984975", type: "text", label: "Last name", required: true, autocomplete: "family-name" },
        { id: "entry.634605013", type: "email", label: "Email", required: true, autocomplete: "email",
          hint: "We’ll communicate with you at this address throughout the project." },
        { id: "entry.1118779335", type: "tel", label: "Phone number", required: true, autocomplete: "tel" }
      ]
    },
    {
      title: "Eligibility",
      fields: [
        { id: "entry.635908958", type: "radio", required: true,
          label: "Do you currently own an iPhone (12 or newer, excluding 16e/17e) or Android (Google Pixel 6+ or Samsung Galaxy S21+)?",
          options: ["Yes", "No"] },
        { id: "entry.262091565", type: "radio", required: true,
          label: "Compensation terms",
          terms: [
            ["Rate:", "You will be compensated per high-quality, approved task recordings submitted."],
            ["Timeline:", "Submissions undergo a quality review process. Payment will be released once your recordings are approved, which typically takes up to two (2) weeks."]
          ],
          options: ["Yes, I confirm that I have read and understood these terms", "No, I opt out"] }
      ]
    },
    {
      title: "Location & equipment",
      fields: [
        { id: "entry.1001769364", type: "text", label: "In what country are you located?", required: true,
          autocomplete: "country-name" },
        { id: "entry.294291103", type: "radio", required: true,
          label: "This study requires acquisition of a headstrap to mount your phone. Would you rather receive the headstrap by mail from us, or order it yourself then get reimbursed after submitting 10 hours of footage?",
          hint: "A maximum of 1 headstrap will be shipped or reimbursed.",
          options: ["Option 1 - We send you the headstrap", "Option 2 - You order the headstrap, then we reimburse you"] },
        { id: "entry.1007363023", type: "textarea", label: "Mailing address", required: true, rows: 3,
          autocomplete: "street-address", hint: "Please include City, State, and Zip Code." }
      ]
    },
    {
      title: "About you",
      fields: [
        { id: "entry.436038420", type: "radio", label: "What is your age?", required: true,
          options: ["Under 18", "18-24", "25-34", "35-44", "45-54", "55-64", "65+"] },
        { id: "entry.1056532508", type: "radio", label: "What is your current employment status?", required: true,
          other: true,
          options: ["Employed full-time", "Employed part-time", "Self-employed", "Student",
                    "Unemployed, looking for work", "Unemployed, not currently looking for work", "Retired"] },
        { id: "entry.1636188540", type: "radio", required: true, other: true,
          label: "Do you have full use and motor skills in both hands and arms?",
          options: ["Yes", "No"] },
        { id: "entry.569805094", type: "radio", required: true,
          label: "If you have children (under 18) living in your primary residence or children that visit frequently, are you able to create an environment where you can record videos without the risk of children appearing in the videos?",
          options: ["Yes", "No"] }
      ]
    },
    {
      title: "Commitment",
      fields: [
        { id: "entry.1866159930", type: "radio", required: true,
          label: "Are you willing and able to record approximately 10 hours of video footage over a 7-day period?",
          options: ["Yes", "No"] },
        { id: "entry.455338226", type: "radio", required: true,
          label: "On average, how many hours per day can you realistically dedicate to recording?",
          hint: "The more hours you contribute, the greater your earning potential.",
          options: ["1-2 hours", "2-3 hours", "3-4 hours", "4-5 hours", "5+ hours"] },
        { id: "entry.2112827502", type: "radio", required: true, scale: true,
          label: "This study involves repeating similar household tasks many times while wearing a headstrap with your phone attached, and following recording rules. This can be repetitive and boring. How comfortable are you with that kind of work?",
          options: ["Very comfortable", "Somewhat comfortable", "Neutral", "Somewhat uncomfortable", "Very uncomfortable"] },
        { id: "entry.1843177012", type: "textarea", required: true, rows: 5,
          label: "Briefly tell us why you’re interested in this study and what makes you a good fit for a detailed, technology-driven home research project:" }
      ]
    }
  ],

  es: [
    {
      title: "Tus datos",
      fields: [
        { id: "entry.911508089", type: "text", label: "Nombre", required: true, autocomplete: "given-name" },
        { id: "entry.484370043", type: "text", label: "Apellido", required: true, autocomplete: "family-name" },
        { id: "entry.1580621736", type: "email", label: "Correo electrónico", required: true, autocomplete: "email",
          hint: "Nos comunicaremos contigo a esta dirección durante todo el proyecto." },
        { id: "entry.1121624736", type: "tel", label: "Número de teléfono", required: true, autocomplete: "tel" }
      ]
    },
    {
      title: "Elegibilidad",
      fields: [
        { id: "entry.1905437570", type: "radio", required: true,
          label: "¿Tienes actualmente un iPhone (12 o posterior, excluyendo 16e/17e) o Android (Google Pixel 6+ o Samsung Galaxy S21+)?",
          options: ["Sí", "No"] },
        { id: "entry.234136974", type: "radio", required: true,
          label: "Términos de compensación",
          terms: [
            ["Tarifa / Compensación:", "Recibirás una compensación por cada grabación de tarea aprobada y de alta calidad que envíes."],
            ["Plazo:", "Las entregas se someten a un proceso de revisión de calidad. El pago se liberará una vez que tus grabaciones sean aprobadas, lo cual suele tardar hasta dos (2) semanas."]
          ],
          options: ["Sí, confirmo que he leído y entendido estos términos.",
                    "No, me doy de baja / prefiero no participar."] }
      ]
    },
    {
      title: "Ubicación y equipo",
      fields: [
        { id: "entry.1427706074", type: "text", label: "¿En qué país se encuentra?", required: true,
          autocomplete: "country-name" },
        { id: "entry.1529050342", type: "radio", required: true,
          label: "Este estudio requiere la adquisición de una correa para la cabeza (headstrap) para montar tu teléfono. ¿Prefieres recibir la correa por correo de nuestra parte, o pedirla tú mismo/a y recibir el reembolso después de enviar 10 horas de grabación?",
          hint: "Se enviará o reembolsará un máximo de 1 correa.",
          options: ["Opción 1 - Nosotros te enviamos la correa para la cabeza.",
                    "Opción 2 - Tú pides la correa para la cabeza y luego te la reembolsamos."] },
        { id: "entry.1284750214", type: "textarea", label: "Dirección postal", required: true, rows: 3,
          autocomplete: "street-address", hint: "Incluye ciudad, estado o provincia y código postal." }
      ]
    },
    {
      title: "Sobre ti",
      fields: [
        { id: "entry.1865982363", type: "radio", label: "¿Cuál es tu edad?", required: true,
          options: ["Menor de 18", "18-24", "25-34", "35-44", "45-54", "55-64", "65+"] },
        { id: "entry.2037461932", type: "radio", label: "¿Cuál es tu situación laboral actual?", required: true,
          other: true,
          options: ["Empleado/a a tiempo completo", "Empleado/a a tiempo parcial",
                    "Trabajador/a independiente / Autónomo/a", "Estudiante",
                    "Desempleado/a, buscando trabajo",
                    "Desempleado/a, actualmente no estoy buscando trabajo", "Jubilado/a"] },
        { id: "entry.1641709507", type: "radio", required: true, other: true,
          label: "¿Tienes pleno uso y habilidades motoras en ambas manos y brazos?",
          options: ["Sí", "No"] },
        { id: "entry.1911184773", type: "radio", required: true,
          label: "No está permitido grabar a menores de 18 años. ¿Puede evitar que aparezcan niños en la grabación?",
          options: ["Sí, confirmo que he leído y entendido estos términos.",
                    "No, me doy de baja / prefiero no participar."] }
      ]
    },
    {
      title: "Compromiso",
      fields: [
        { id: "entry.742370338", type: "radio", required: true,
          label: "¿Está dispuesto y en condiciones de grabar aproximadamente 10 horas de vídeo en un periodo de 7 días?",
          options: ["Sí", "No"] },
        { id: "entry.754331099", type: "radio", required: true,
          label: "¿Cuántas horas al día puedes dedicar realmente a grabar, en promedio?",
          hint: "Ten en cuenta que, cuantas más horas dediques, ¡mayor será tu potencial de ganancias!",
          options: ["1-2 horas", "2-3 horas", "3-4 horas", "5+ horas"] },
        { id: "entry.1308298013", type: "radio", required: true, scale: true,
          label: "Este estudio implica repetir tareas del hogar similares muchas veces mientras usas una correa en la cabeza con tu teléfono sujeto, y seguir reglas de grabación. Esto puede resultar repetitivo y aburrido. ¿Qué tan cómodo/a te sientes con este tipo de trabajo?",
          options: ["Muy cómodo/a", "Algo cómodo/a", "Neutral", "Algo incómodo/a", "Muy incómodo/a"] },
        { id: "entry.1390546596", type: "textarea", required: true, rows: 5,
          label: "Cuéntanos brevemente por qué estás interesado/a en este estudio y qué te hace un buen candidato/a para un proyecto detallado de investigación en el hogar guiado por tecnología:" }
      ]
    }
  ],

  pt: [
    {
      title: "Seus dados",
      fields: [
        { id: "entry.1235600512", type: "text", label: "Nome", required: true, autocomplete: "given-name" },
        { id: "entry.143990848", type: "text", label: "Sobrenome", required: true, autocomplete: "family-name" },
        { id: "entry.1904547790", type: "email", label: "Email", required: true, autocomplete: "email",
          hint: "Entraremos em contato por este e-mail durante todo o projeto." },
        { id: "entry.1931444599", type: "tel", label: "Número de telefone", required: true, autocomplete: "tel" }
      ]
    },
    {
      title: "Elegibilidade",
      fields: [
        { id: "entry.261175201", type: "radio", required: true,
          label: "Você possui atualmente um iPhone (12 ou mais recente, exceto 16e/17e) ou um Android (Google Pixel 6+ ou Samsung Galaxy S21+)?",
          options: ["Sim", "Não"] },
        { id: "entry.1747182626", type: "radio", required: true,
          label: "Termos de remuneração",
          terms: [
            ["Remuneração:", "Você será remunerado por cada gravação de tarefa aprovada e de alta qualidade enviada."],
            ["Prazo:", "Os envios passam por um processo de revisão de qualidade. O pagamento será liberado após a aprovação das suas gravações, o que geralmente leva até duas (2) semanas."]
          ],
          options: ["Sim, confirmo que li e compreendi estes termos.", "Não, eu não quero participar."] }
      ]
    },
    {
      title: "Localização e equipamento",
      fields: [
        { id: "entry.534969604", type: "text", label: "Em que país você está localizado?", required: true,
          autocomplete: "country-name" },
        { id: "entry.1946552456", type: "radio", required: true,
          label: "Este estudo exige a aquisição de uma faixa de cabeça para fixar o seu celular. Você prefere receber a faixa de cabeça pelo correio, enviada por nós, ou adquiri-la por conta própria e ser reembolsado após enviar 10 horas de filmagem?",
          hint: "Será enviada ou reembolsada no máximo 1 faixa de cabeça.",
          options: ["Opção 1 - Enviamos a você a faixa de cabeça.",
                    "Opção 2 - Você compra a faixa de cabeça e nós o reembolsamos."] },
        { id: "entry.954028533", type: "textarea", label: "Endereço para correspondência", required: true, rows: 3,
          autocomplete: "street-address", hint: "Inclua cidade, estado e CEP." }
      ]
    },
    {
      title: "Sobre você",
      fields: [
        { id: "entry.1526636763", type: "radio", label: "Qual é a sua idade?", required: true,
          options: ["Menor de 18 anos", "18-24", "25-34", "35-44", "45-54", "55-64", "65+"] },
        { id: "entry.676935844", type: "radio", label: "Qual é a sua situação profissional atual?", required: true,
          other: true,
          options: ["Empregado em tempo integral", "Empregado em tempo parcial",
                    "Trabalhador por conta própria", "Estudante",
                    "Desempregado, em busca de trabalho",
                    "Desempregado, sem procurar emprego no momento", "Aposentado(a)"] },
        { id: "entry.1031680639", type: "radio", required: true, other: true,
          label: "Você tem pleno uso e capacidade motora em ambas as mãos e braços?",
          options: ["Sim", "Não"] },
        { id: "entry.1994777107", type: "radio", required: true,
          label: "Não é permitido filmar ou gravar pessoas menores de 18 anos. Você pode impedir que crianças apareçam na gravação?",
          options: ["Sim, confirmo que li e entendi estes termos.",
                    "Não, vou cancelar minha participação / prefiro não participar."] }
      ]
    },
    {
      title: "Compromisso",
      fields: [
        { id: "entry.92582148", type: "radio", required: true,
          label: "Você tem disponibilidade e capacidade para gravar aproximadamente 10 horas de vídeo ao longo de um período de 7 dias?",
          options: ["Sim", "Não"] },
        { id: "entry.1822834430", type: "radio", required: true,
          label: "Em média, quantas horas por dia você consegue dedicar realisticamente à gravação?",
          hint: "Lembre-se de que, quanto mais horas você dedicar, maior será o seu potencial de ganhos!",
          options: ["1-2 horas", "2-3 horas", "3-4 horas", "4-5 horas", "5+ horas"] },
        { id: "entry.1423467999", type: "radio", required: true, scale: true,
          label: "Este estudo envolve repetir diversas vezes tarefas domésticas semelhantes enquanto se usa uma faixa de cabeça com o celular acoplado, seguindo regras de gravação. Isso pode ser repetitivo e monótono. Quão confortável você se sente com esse tipo de trabalho?",
          options: ["Muito confortável", "Confortável", "Neutro", "Desconfortável", "Muito desconfortável"] },
        { id: "entry.220699661", type: "textarea", required: true, rows: 5,
          label: "Conte-nos brevemente por que você tem interesse neste estudo e o que faz de você um bom candidato para um projeto de pesquisa domiciliar detalhado e baseado em tecnologia:" }
      ]
    }
  ]
};
