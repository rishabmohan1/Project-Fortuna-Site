/* =========================================================
   Project Fortuna, Participant Screening
   Renders the multi-step, multilingual form from the data in
   questions.js and posts responses into the existing Google
   Form (which feeds the linked responses spreadsheet).
   ========================================================= */

var FORM_ACTION =
  "https://docs.google.com/forms/d/e/1FAIpQLSchFw48aYxR1LJYJo9ESyvIPqH_Dp1bw6vQweksVGiS8cYpTw/formResponse";

/* The live Google Form has one page (0) with the language question,
   which routes to a language-specific section (1 = English, 2 =
   Español, 3 = Português). That section is the last page: the form has
   no separate closing "thank you" page, so pageHistory must not name
   one, or Google rejects the submission outright (HTTP 400). */
var SECTION_PAGE = { en: 1, es: 2, pt: 3 };

var form = document.getElementById("screening-form");
var stepsContainer = document.getElementById("steps-container");

var nextBtn = document.getElementById("next-btn");
var backBtn = document.getElementById("back-btn");
var submitBtn = document.getElementById("submit-btn");
var submitLabel = submitBtn.querySelector(".btn-label");
var progressFill = document.getElementById("progress-fill");
var progressBar = document.getElementById("progress-bar");
var progressLabel = document.getElementById("progress-label");
var progressPct = document.getElementById("progress-pct");
var progressWrap = document.getElementById("progress-wrap");
var stepAnnounce = document.getElementById("step-announce");
var errorSummary = document.getElementById("error-summary");
var errorSummaryTitle = document.getElementById("error-summary-title");
var errorList = document.getElementById("error-summary-list");
var successState = document.getElementById("success-state");
var submitError = document.getElementById("submit-error");
var intro = document.getElementById("intro");

document.getElementById("year").textContent = new Date().getFullYear();

var lang = null;
var current = 0;
/* Fixed regardless of language: 1 language step + 5 survey sections
   (every SURVEYS[code] array has exactly 5 sections). */
var totalSteps = 6;
var steps = []; // cached once the shells exist; DOM nodes are reused across language switches

/* ---------------------------------------------------------
   HTML building
   --------------------------------------------------------- */

function esc(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function elId(fieldId) {
  return "f_" + fieldId.replace(/\./g, "_");
}

function fieldHTML(field, ui) {
  var id = elId(field.id);
  var reqMark = field.required
    ? ' <abbr class="req" title="' + esc(ui.requiredAbbr) + '">*</abbr>'
    : ' <span class="optional">' + esc(ui.optional) + "</span>";
  var hintHTML = field.hint ? '<p class="hint">' + esc(field.hint) + "</p>" : "";

  if (field.type === "radio") {
    var optionsHTML = field.options
      .map(function (opt) {
        return (
          '<label class="option"><input type="radio" name="' + field.id +
          '" value="' + esc(opt) + '"><span>' + esc(opt) + "</span></label>"
        );
      })
      .join("");

    var otherHTML = "";
    if (field.other) {
      optionsHTML +=
        '<label class="option"><input type="radio" name="' + field.id +
        '" value="__other_option__"><span>' + esc(ui.otherLabel) + "</span></label>";
      otherHTML =
        '<div class="other-wrap" hidden>' +
        '<label class="sr-only" for="' + id + '_other">' + esc(ui.otherPlaceholder) + "</label>" +
        '<input type="text" id="' + id + '_other" name="' + field.id +
        '.other_option_response" placeholder="' + esc(ui.otherPlaceholder) + '"></div>';
    }

    var termsHTML = "";
    if (field.terms) {
      termsHTML =
        '<div class="terms-box">' +
        field.terms
          .map(function (t) {
            return "<p><strong>" + esc(t[0]) + "</strong> " + esc(t[1]) + "</p>";
          })
          .join("") +
        "</div>";
    }

    return (
      '<div class="field" data-field>' +
      '<fieldset class="radio-group' + (field.scale ? " scale" : "") + '" data-required' +
      (field.other ? ' data-other="' + field.id + '"' : "") + ">" +
      "<legend>" + esc(field.label) + reqMark + "</legend>" +
      hintHTML + termsHTML + optionsHTML + otherHTML +
      "</fieldset>" +
      '<p class="error-msg"></p>' +
      "</div>"
    );
  }

  if (field.type === "textarea") {
    return (
      '<div class="field" data-field>' +
      '<label for="' + id + '">' + esc(field.label) + reqMark + "</label>" +
      hintHTML +
      '<textarea id="' + id + '" name="' + field.id + '" rows="' + (field.rows || 4) + '"' +
      (field.autocomplete ? ' autocomplete="' + field.autocomplete + '"' : "") +
      (field.required ? " data-required" : "") +
      "></textarea>" +
      '<p class="error-msg"></p>' +
      "</div>"
    );
  }

  // text / email / tel
  var extra = "";
  if (field.type === "email") extra = ' inputmode="email" data-type="email"';
  if (field.type === "tel") extra = ' inputmode="tel" data-type="phone"';

  return (
    '<div class="field" data-field>' +
    '<label for="' + id + '">' + esc(field.label) + reqMark + "</label>" +
    hintHTML +
    '<input type="' + field.type + '" id="' + id + '" name="' + field.id + '"' +
    (field.autocomplete ? ' autocomplete="' + field.autocomplete + '"' : "") +
    extra + (field.required ? " data-required" : "") + ">" +
    '<p class="error-msg"></p>' +
    "</div>"
  );
}

function buildLanguageStepHTML() {
  var ls = UI.en.languageStep;
  var opts = [
    ["English", "en"],
    ["Español", "es"],
    ["Português", "pt"]
  ];
  var optionsHTML = opts
    .map(function (o) {
      return (
        '<label class="option"><input type="radio" name="' + LANG_FIELD +
        '" value="' + esc(o[0]) + '" data-lang="' + o[1] + '"><span>' + esc(o[0]) + "</span></label>"
      );
    })
    .join("");

  return (
    '<fieldset class="step" data-step="0">' +
    '<legend class="sr-only">' + esc(ls.title) + "</legend>" +
    '<h2 class="step-title" id="step-title-0" tabindex="-1">' + esc(ls.title) + "</h2>" +
    '<div class="field" data-field>' +
    '<fieldset class="radio-group" data-required>' +
    "<legend>" + esc(ls.question) + ' <abbr class="req" title="required">*</abbr></legend>' +
    optionsHTML +
    "</fieldset>" +
    '<p class="error-msg"></p>' +
    "</div>" +
    "</fieldset>"
  );
}

function buildEmptyStepShells() {
  var html = "";
  for (var i = 1; i <= 5; i++) {
    html += '<fieldset class="step" data-step="' + i + '" hidden></fieldset>';
  }
  return html;
}

/* Populates steps[1..5] with the chosen language's survey content.
   The fieldset elements themselves are never replaced, only their
   contents, so `steps` array references stay valid. */
function setSurveyLanguage(code) {
  var ui = UI[code];
  var sections = SURVEYS[code];

  for (var i = 0; i < sections.length; i++) {
    var section = sections[i];
    var stepEl = steps[i + 1];
    stepEl.innerHTML =
      '<legend class="sr-only">' + esc(section.title) + "</legend>" +
      '<h2 class="step-title" id="step-title-' + (i + 1) + '" tabindex="-1">' + esc(section.title) + "</h2>" +
      section.fields.map(function (f) { return fieldHTML(f, ui); }).join("");
  }

  lang = code;
  document.documentElement.lang = code;
  refreshOtherInputs();
}

function localizeUI(code) {
  var ui = UI[code];

  intro.hidden = false;
  document.getElementById("intro-eyebrow").textContent = ui.intro.eyebrow;
  document.getElementById("intro-title").textContent = ui.intro.title;
  document.getElementById("intro-body").textContent = ui.intro.body;
  document.getElementById("intro-points").innerHTML = ui.intro.points
    .map(function (p) { return '<li><span class="dot" aria-hidden="true"></span> ' + esc(p) + "</li>"; })
    .join("");
  document.getElementById("intro-note").textContent = ui.intro.note;

  backBtn.textContent = ui.nav.back;
  nextBtn.textContent = ui.nav.continue;
  submitLabel.textContent = ui.nav.submit;

  errorSummaryTitle.textContent = ui.errorSummaryTitle;
  document.getElementById("form-footnote").textContent = ui.footnote;

  document.getElementById("success-title").textContent = ui.success.title;
  document.getElementById("success-body").innerHTML =
    esc(ui.success.body) + ' <a href="mailto:support@innodatainc.zohodesk.com">support@innodatainc.zohodesk.com</a>.';

  document.getElementById("submit-error-title").textContent = ui.submitError.title;
  document.getElementById("submit-error-body").innerHTML =
    esc(ui.submitError.body) + ' <a href="mailto:support@innodatainc.zohodesk.com">support@innodatainc.zohodesk.com</a>.';
}

/* ---------------------------------------------------------
   "Other" option, reveal the free-text follow-up
   --------------------------------------------------------- */

function refreshOtherInputs() {
  Array.prototype.forEach.call(document.querySelectorAll("[data-other]"), function (group) {
    var wrap = group.querySelector(".other-wrap");
    if (!wrap) return;
    var picked = group.querySelector('input[type="radio"]:checked');
    var show = !!picked && picked.value === "__other_option__";

    wrap.hidden = !show;
    Array.prototype.forEach.call(wrap.querySelectorAll("input"), function (el) {
      el.disabled = !show;
    });
    if (show) {
      var box = wrap.querySelector("input");
      if (box && document.activeElement !== box) box.focus();
    }
  });
}

form.addEventListener("change", function (e) {
  if (e.target.type === "radio") {
    refreshOtherInputs();
    var field = e.target.closest("[data-field]");
    if (field) clearFieldError(field);
  }
  refreshSubmitVisibility();
});

form.addEventListener("input", function (e) {
  var field = e.target.closest("[data-field]");
  if (field && field.classList.contains("invalid")) clearFieldError(field);
  refreshSubmitVisibility();
});

/* ---------------------------------------------------------
   Validation
   --------------------------------------------------------- */

function clearFieldError(field) {
  field.classList.remove("invalid");
  var msg = field.querySelector(".error-msg");
  if (msg) msg.textContent = "";
  var group = field.querySelector(".radio-group");
  if (group) group.removeAttribute("aria-invalid");
  Array.prototype.forEach.call(field.querySelectorAll("input, textarea"), function (el) {
    el.removeAttribute("aria-invalid");
  });
}

function setFieldError(field, message) {
  field.classList.add("invalid");
  var msg = field.querySelector(".error-msg");
  if (msg) msg.textContent = message;

  var group = field.querySelector(".radio-group");
  if (group) {
    group.setAttribute("aria-invalid", "true");
  } else {
    var input = field.querySelector("input, textarea");
    if (input) input.setAttribute("aria-invalid", "true");
  }
}

function labelFor(field) {
  var source = field.querySelector(".radio-group > legend") || field.querySelector("label");
  if (!source) return "This question";
  var text = source.textContent.replace(/\*/g, "").replace(/\s+/g, " ").trim();
  return text.length > 72 ? text.slice(0, 69).trimEnd() + "…" : text;
}

function focusTargetFor(field) {
  return field.querySelector("input:not([disabled]), textarea:not([disabled])");
}

function isEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);
}

function isPhone(value) {
  var digits = value.replace(/\D/g, "");
  return digits.length >= 7 && digits.length <= 15;
}

/* Validates one step. Pass `silent` to check completeness without
   touching error styling, used by the live check that decides
   whether Submit is available. */
function validateStep(stepEl, silent) {
  var ui = UI[lang || "en"];
  var problems = [];
  var fields = Array.prototype.slice.call(stepEl.querySelectorAll("[data-field]"));

  fields.forEach(function (field) {
    if (field.hidden) return;
    if (!silent) clearFieldError(field);

    var group = field.querySelector(".radio-group[data-required]");
    if (group) {
      var name = group.querySelector('input[type="radio"]').name;
      var picked = form.querySelector('input[name="' + name + '"]:checked');

      if (!picked) {
        problems.push({ field: field, message: ui.errors.select });
        return;
      }
      if (picked.value === "__other_option__") {
        var other = field.querySelector(".other-wrap input:not([disabled])");
        if (other && !other.value.trim()) {
          problems.push({ field: field, message: ui.errors.other });
        }
      }
      return;
    }

    var input = field.querySelector("[data-required]");
    if (!input || input.disabled) return;

    var value = input.value.trim();
    if (!value) {
      problems.push({ field: field, message: ui.errors.required });
      return;
    }
    if (input.dataset.type === "email" && !isEmail(value)) {
      problems.push({ field: field, message: ui.errors.email });
    }
    if (input.dataset.type === "phone" && !isPhone(value)) {
      problems.push({ field: field, message: ui.errors.phone });
    }
  });

  return problems;
}

function findFirstIncompleteStep() {
  for (var i = 0; i < steps.length; i++) {
    var problems = validateStep(steps[i]);
    if (problems.length) return { index: i, problems: problems };
  }
  return null;
}

function isFormComplete() {
  for (var i = 0; i < steps.length; i++) {
    if (validateStep(steps[i], true).length) return false;
  }
  return true;
}

/* Submit only exists once the applicant is on the final step AND every
   question across all steps is answered. Until then Continue holds
   that slot; both are .btn-primary, so the width is identical. */
function refreshSubmitVisibility(index) {
  if (typeof index !== "number") index = current;
  var ready = index === totalSteps - 1 && isFormComplete();
  submitBtn.hidden = !ready;
  nextBtn.hidden = ready;
}

function showProblems(problems) {
  errorList.innerHTML = "";

  problems.forEach(function (p) {
    setFieldError(p.field, p.message);

    var target = focusTargetFor(p.field);
    var li = document.createElement("li");
    var a = document.createElement("a");
    a.href = "#";
    a.textContent = labelFor(p.field) + ": " + p.message;
    a.addEventListener("click", function (e) {
      e.preventDefault();
      if (target) target.focus();
    });
    li.appendChild(a);
    errorList.appendChild(li);
  });

  errorSummary.hidden = false;
  errorSummary.focus();
}

function hideProblems() {
  errorSummary.hidden = true;
  errorList.innerHTML = "";
}

/* ---------------------------------------------------------
   Step navigation
   --------------------------------------------------------- */

function renderStep(index, opts) {
  opts = opts || {};
  var ui = UI[lang || "en"];

  steps.forEach(function (s, i) { s.hidden = i !== index; });

  var pct = Math.round(((index + 1) / totalSteps) * 100);
  progressFill.style.width = pct + "%";
  progressBar.setAttribute("aria-valuenow", String(pct));
  progressLabel.textContent = ui.stepOf.replace("{n}", index + 1).replace("{total}", totalSteps);
  progressPct.textContent = pct + "%";

  backBtn.hidden = index === 0;
  refreshSubmitVisibility(index);

  var heading = steps[index].querySelector(".step-title");
  stepAnnounce.textContent =
    ui.stepOf.replace("{n}", index + 1).replace("{total}", totalSteps) +
    (heading ? ": " + heading.textContent : "");

  if (!opts.silent) {
    if (heading) heading.focus();
    var card = document.querySelector(".form-card");
    if (card) {
      var top = card.getBoundingClientRect().top + window.pageYOffset - 20;
      window.scrollTo({ top: top, behavior: "smooth" });
    }
  }
}

nextBtn.addEventListener("click", function () {
  // On the final step there is nowhere left to go, so Continue's only
  // job is to point out whatever is still unanswered.
  if (current === totalSteps - 1) {
    var incomplete = findFirstIncompleteStep();
    if (incomplete) {
      if (incomplete.index !== current) {
        current = incomplete.index;
        renderStep(current, { silent: true });
      }
      showProblems(incomplete.problems);
    }
    refreshSubmitVisibility();
    return;
  }

  var problems = validateStep(steps[current]);
  if (problems.length) {
    showProblems(problems);
    return;
  }
  hideProblems();

  if (current === 0) {
    var checked = steps[0].querySelector('input[type="radio"]:checked');
    var code = checked.getAttribute("data-lang");
    if (code !== lang) setSurveyLanguage(code);
    localizeUI(code);
  }

  current = Math.min(current + 1, totalSteps - 1);
  renderStep(current);
});

backBtn.addEventListener("click", function () {
  hideProblems();
  current = Math.max(current - 1, 0);
  renderStep(current);
});

/* Enter should advance the form, not fire the hidden submit button */
form.addEventListener("keydown", function (e) {
  if (e.key !== "Enter") return;
  if (e.target.tagName === "TEXTAREA") return;
  if (e.target.tagName === "INPUT") {
    e.preventDefault();
    (current === totalSteps - 1 ? submitBtn : nextBtn).click();
  }
});

/* ---------------------------------------------------------
   Submission
   --------------------------------------------------------- */

/* Google's per-session form token: a signed 19-digit integer. Built
   from digits rather than arithmetic, which would exceed
   Number.MAX_SAFE_INTEGER and round the tail to zeros. */
function randomFbzx() {
  var digits = "";
  for (var i = 0; i < 18; i++) digits += Math.floor(Math.random() * 10);
  return "-" + (Math.floor(Math.random() * 9) + 1) + digits;
}

function buildPayload() {
  var params = new URLSearchParams();
  var data = new FormData(form);

  data.forEach(function (value, key) {
    if (key === "company-website") return; // honeypot never reaches Google
    if (typeof value === "string" && !value.trim()) return;
    params.append(key, value);
  });

  params.append("fvv", "1");
  params.append("pageHistory", [0, SECTION_PAGE[lang]].join(","));
  params.append("fbzx", randomFbzx());
  params.append("submit", "Submit");

  return params;
}

function showSuccess() {
  form.hidden = true;
  progressWrap.hidden = true;
  intro.hidden = true;
  successState.hidden = false;
  successState.focus();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function setSubmitting(on) {
  var ui = UI[lang || "en"];
  submitBtn.disabled = on;
  nextBtn.disabled = on;
  submitBtn.querySelector(".spinner").hidden = !on;
  submitLabel.textContent = on ? ui.nav.submitting : ui.nav.submit;
}

function submitForm() {
  // A filled honeypot means a bot; show success without storing anything
  var trap = form.querySelector('[name="company-website"]');
  if (trap && trap.value) {
    showSuccess();
    return;
  }

  submitError.hidden = true;
  setSubmitting(true);

  fetch(FORM_ACTION, {
    method: "POST",
    mode: "no-cors",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: buildPayload().toString()
  })
    .then(function () {
      // no-cors responses are opaque, so a resolved promise is our success signal
      showSuccess();
    })
    .catch(function () {
      setSubmitting(false);
      submitError.hidden = false;
      submitError.focus();
    });
}

form.addEventListener("submit", function (e) {
  e.preventDefault();

  // Re-check every step, not just the last one: a partially filled form
  // must never reach the spreadsheet.
  var incomplete = findFirstIncompleteStep();
  if (incomplete) {
    if (incomplete.index !== current) {
      current = incomplete.index;
      renderStep(current, { silent: true });
    }
    showProblems(incomplete.problems);
    return;
  }

  hideProblems();
  submitForm();
});

/* ---------------------------------------------------------
   Init
   --------------------------------------------------------- */

stepsContainer.innerHTML = buildLanguageStepHTML() + buildEmptyStepShells();
steps = Array.prototype.slice.call(document.querySelectorAll(".step"));

setSurveyLanguage("en");
localizeUI("en");
renderStep(0, { silent: true });
